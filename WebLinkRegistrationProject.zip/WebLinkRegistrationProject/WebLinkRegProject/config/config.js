

module.exports = {
    dbHost: 'weblinksdb.ctzzdvu4ji7r.us-east-1.rds.amazonaws.com',
    username: 'webadmin',
    password: 'admin1234',
    database: 'WebLinksDB'
}