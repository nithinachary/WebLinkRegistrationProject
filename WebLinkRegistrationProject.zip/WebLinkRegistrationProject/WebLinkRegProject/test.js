function calculateAge(birthday) { // birthday is a date
    var ageDifMs = Date.now() - birthday;
    var ageDate = new Date(ageDifMs); // miliseconds from epoch
    return Math.abs(ageDate.getUTCFullYear() - 1970);
}

console.log(calculateAge('2020-03-17T03:19:33.000Z'));




const getAge = (dateOfBirth, dateToCalculate = new Date()) => {
    const dob = new Date(dateOfBirth).getTime();
    const dateToCompare = new Date(dateToCalculate).getTime();
    console.log(dob, dateToCompare);
    const age = (dateToCompare - dob) / (365 * 24 * 60 * 60 * 1000);
    console.log(age);
    return Math.floor(age);
};



console.log(getAge('2019-03-17T03:19:33.000Z'));
