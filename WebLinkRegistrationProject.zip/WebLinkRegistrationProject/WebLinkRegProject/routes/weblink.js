var express = require('express');
var router = express.Router();
var weblinkComponenet = require('../components/weblink')

const db = require('../db/db');

/* GET All Registered Link */
router.get('/link', function (req, res, next) {
  console.log('Inside GET: /link route');
  
  weblinkComponenet.getWebLink(req.body, function (err, response) {
    if (err) {
      res.status(err.code, {
        'Content-Type': 'application/json; charset=utf-8'
      });
      res.end(err.message);
    } else {
      res.status(response.code, {
        'Content-Type': 'application/json; charset=utf-8'
      });
      res.end(JSON.stringify(response));
    }
  });
});

/* POST Register New  Link */
router.post('/link', function (req, res, next) {
  console.log('Inside POST: /link route');
  
  weblinkComponenet.registerWebLink(req.body, function (err, response) {
    if (err) {
      res.end(err);
    } else {
      res.status(response.code, {
        'Content-Type': 'application/json; charset=utf-8'
      });
      res.end(JSON.stringify(response));
    }
  });
});

/* PUT Update Link Visit Count*/
router.put('/link', function (req, res, next) {
  console.log('Inside PUT: /link route');
  
  weblinkComponenet.updateWebLink(req.body, function (err, response) {
    if (err) {
      res.end(err);
    } else {
      res.status(response.code, {
        'Content-Type': 'application/json; charset=utf-8'
      });
      res.end(JSON.stringify(response));
    }
  });
});


/* DELETE Link oldan than 1 year */
router.delete('/link', function (req, res, next) {
  console.log('Inside DELETE: /link route');
  
  weblinkComponenet.deleteWebLink(req.body, function (err, response) {
    if (err) {
      res.end(err);
    } else {
      res.status(response.code, {
        'Content-Type': 'application/json; charset=utf-8'
      });
      res.end(JSON.stringify(response));
    }
  });
});

/* GET Search Popular Link By Category, Sub-Category or Both */
router.get('/getPopularLink', function (req, res, next) {
  console.log('Inside GET: /getPopularLink route');

  weblinkComponenet.searchPopularLink(req.query, function (err, response) {
    if (err) {
      res.end(err);
    } else {
      res.status(response.code, {
        'Content-Type': 'application/json; charset=utf-8'
      });
      res.end(JSON.stringify(response));
    }
  });
});

/* PUT Update Recent Visitor On Link */
router.put('/updateRecentVisitor', function (req, res, next) {
  console.log('Inside PUT: /updateRecentVisitor route');
  
  weblinkComponenet.updateRecentVisitor(req.body, function (err, response) {
    if (err) {
      res.end(err);
    } else {
      res.status(response.code, {
        'Content-Type': 'application/json; charset=utf-8'
      });
      res.end(JSON.stringify(response));
    }
  });
});

/* GET Recent Visitor List On All Link */
router.get('/getRecentVisitorAllLinks', function (req, res, next) {
  console.log('Inside GET: /getRecentVisitorAllLinks route');
  
  weblinkComponenet.getRecentVisitorAllLinks(req, function (err, response) {
    if (err) {
      res.end(err);
    } else {
      res.status(response.code, {
        'Content-Type': 'application/json; charset=utf-8'
      });
      res.end(JSON.stringify(response));
    }
  });
});

/* GET Recent Visitor List On A Link */
router.get('/getRecentVisitor/:weblink', function (req, res, next) {
  console.log('Inside GET: /getRecentVisitor route');
  
  weblinkComponenet.getRecentVisitor(req.params, function (err, response) {
    if (err) {
      res.end(err);
    } else {
      res.status(response.code, {
        'Content-Type': 'application/json; charset=utf-8'
      });
      res.end(JSON.stringify(response));
    }
  });
});

/* PUT Deregester A Link */
router.put('/deregisterLink', function (req, res, next) {
  console.log('Inside PUT: /deregisterLink route');

  weblinkComponenet.deregisterLink(req.body, function (err, response) {
    if (err) {
      res.end(err);
    } else {
      res.status(response.code, {
        'Content-Type': 'application/json; charset=utf-8'
      });
      res.end(JSON.stringify(response));
    }
  });
});

module.exports = router;
