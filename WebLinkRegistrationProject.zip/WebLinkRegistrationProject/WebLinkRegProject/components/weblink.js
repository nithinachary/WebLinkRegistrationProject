const db = require('../db/db');
const JsonResponse = require('../utils/jsonResponse');

/* GET All Registered Link */
const getWebLink = function (req, callback) {
    try {
        let query = 'SELECT * FROM weblink';
        db.query(query, null, function (error, response) {
            if (error) {
                console.log('Error message', error);
                callback(JsonResponse(500, 'FAILED', JSON.stringify(error), null));
            } else {
                console.log('Inside Get Query');
                callback(null, JsonResponse(200, 'SUCCESS', 'Successfullly Fetched All Registered Links', response));
            }
        });
    } catch (ex) {
        console.log('exception', ex);
        callback(JsonResponse(500, 'FAILED', JSON.stringify(ex), null));
    }
}

/* Register New  Link */
const registerWebLink = function (req, callback) {
    try {
        let weblink = req.weblink;
        let category = req.category;
        let subCategory = req.subCategory;
        let query = 'INSERT INTO `WebLinksDB`.`weblink` (weblink, category, subCategory, visitCount, createdOn, recentVisitor, isActive) VALUES (' + "'" + weblink + "','" + category + "','" + subCategory + "', 0, NOW(), null, true)";
        console.log(query)
        db.query(query, null, function (error, response) {
                if (error) {
                    console.log('Error message', error);
                    callback(JsonResponse(500, 'FAILED', JSON.stringify(error), null))
                } else {
                    console.log('Inside Register Query');
                    console.log(response.insertId);
                    callback(null, JsonResponse(200, 'SUCCESS', 'Successfullly Registered The Link', 'Registratoion Id: ' + response.insertId));
                }
        });
    } catch (ex) {
        console.log('exception', ex);
        callback(JsonResponse(500, 'FAILED', JSON.stringify(ex), null));
    }
}

/* Updates Link's Visit Count*/
const updateWebLink = function (req, callback) {
    try {
        let weblink = req.weblink;
        let previousCount;
        let visitCount;
        let searchQuery = 'SELECT visitCount FROM `WebLinksDB`.`weblink` WHERE weblink = ' + "'" + weblink + "'";
        db.query(searchQuery, null, function (error, response) {
            if (error) {
                console.log('Error message', error);
                callback(JsonResponse(500, 'FAILED', JSON.stringify(error), null))
            } else {
                console.log('Inside Update Query');
                previousCount = response[0].visitCount;
                visitCount = previousCount + 1;
                let updateQuery = 'UPDATE `WebLinksDB`.`weblink` SET `visitCount` = ' + visitCount + ' where weblink = ' + "'" + weblink + "'";
                db.query(updateQuery, null, function (error, response) {
                    if (error) {
                        console.log('Error message', error);
                        callback(JsonResponse(500, 'FAILED', JSON.stringify(error), null))
                    } else {
                        callback(null, JsonResponse(200, 'SUCCESS', 'Successfully Updated The Visit Count', 'Previous Count - ' + previousCount + ', Current Count - ' + visitCount));
                    }
                });
            }
        });
    } catch (ex) {
        console.log('exception', ex);
        callback(JsonResponse(500, 'FAILED', JSON.stringify(ex), null));
    }
};

/* Search Popular Link By Category, Sub-Category or Both */
const searchPopularLink = function (req, callback) {
    try {
        let category = req.category;
        let subCategory = req.subCategory;
        var searchQuery;
        if (category != null && subCategory != null) {
            searchQuery = 'SELECT weblink, max(visitCount) FROM `WebLinksDB`.`weblink` WHERE category = ' + category + ' and subCategory = ' + subCategory;
        } else if (subCategory != null && subCategory != undefined) {
            searchQuery = 'SELECT weblink, max(visitCount) FROM `WebLinksDB`.`weblink` WHERE subCategory = ' + subCategory;
        } else if (category != null && category != undefined) {
            searchQuery = 'SELECT weblink, max(visitCount) FROM `WebLinksDB`.`weblink` WHERE category = ' + category;
        }
        db.query(searchQuery, null, function (error, response) {
            if (error) {
                console.log('Error message', error);
                callback(JsonResponse(500, 'FAILED', JSON.stringify(error), null))
            } else {
                console.log('Inside Search Query');
                callback(null, JsonResponse(200, 'SUCCESS', 'Popular Link Found', response));
            }
        });
    }catch (ex) {
        console.log('exception', ex);
        callback(JsonResponse(500, 'FAILED', JSON.stringify(ex), null));
    }
};

/* Update's Recent Visitor On Link */
const updateRecentVisitor = function (req, callback) {
    try {
        let userId = req.userId;
        let weblink = req.weblink;
        let findQuery = 'SELECT weblink FROM `WebLinksDB`.`weblink` WHERE weblink = ' + "'" + weblink + "'";
        db.query(findQuery, null, function (error, response) {
            if (error) {
                console.log('Error message', error);
                callback(JsonResponse(500, 'FAILED', JSON.stringify(error), null))
            } else {
                console.log('Inside Find Weblink Query');
                if(response.length > 0){
                    let visitorUpdateQuery = 'UPDATE `WebLinksDB`.`weblink` SET `recentVisitor` = ' + userId + ' where weblink = ' + "'" + weblink + "'";
                        db.query(visitorUpdateQuery, null, function (error, response) {
                            if (error) {
                                console.log('Error message', error);
                                callback(JsonResponse(500, 'FAILED', JSON.stringify(error), null))
                            } else {
                                console.log('Inside Update Visitor Query');
                                callback(null, JsonResponse(200, 'SUCCESS', 'Successfully Visitor Updated', null));
                            }
                        });
                }else{
                    callback(null, JsonResponse(404, 'NOT FOUND', 'No Such Weblink Registered', null));
                }  
            }
        });
    }catch (ex) {
        console.log('exception', ex);
        callback(JsonResponse(500, 'FAILED', JSON.stringify(ex), null));
    }
};

/* Finds Visitor List On All Link */
const getRecentVisitorAllLinks = function (req, callback) {
    try {
        let getRecentVisitor = 'SELECT weblink.weblink, user.firstname FROM weblink weblink LEFT JOIN user ON weblink.recentVisitor = user.userId';
        db.query(getRecentVisitor, null, function (error, response) {
            if (error) {
                console.log('Error message', error);
                callback(JsonResponse(500, 'FAILED', JSON.stringify(error), null))
            } else {
                console.log('Get Recent Visitor All Links Query');
                callback(null, JsonResponse(200, 'SUCCESS', 'Successfully Fetched All Links Recent Visitors', response));
            }
        });
    }catch (ex) {
        console.log('exception', ex);
        callback(JsonResponse(500, 'FAILED', JSON.stringify(ex), null));
    }
};

/* Finds Recent Visitor List On Given Link */
const getRecentVisitor = function (req, callback) {
    try {
        let weblink = req.weblink;
        let findQuery = 'SELECT weblink FROM `WebLinksDB`.`weblink` WHERE weblink = ' + "'" + weblink + "'";
        db.query(findQuery, null, function (error, response) {
            if (error) {
                console.log('Error message', error);
                callback(JsonResponse(500, 'FAILED', JSON.stringify(error), null))
            } else {
                console.log('Inside Find Weblink Query');
                if(response.length > 0){
                    let getRecentVisitor = 'SELECT weblink.weblink, user.firstname FROM weblink weblink LEFT JOIN user ON weblink.recentVisitor = user.userId where weblink.weblink = ' + "'" + weblink + "'";
                    db.query(getRecentVisitor, null, function (error, response) {
                        if (error) {
                            console.log('Error message', error);
                            callback(JsonResponse(500, 'FAILED', JSON.stringify(error), null))
                        } else {
                            console.log('Get recent visitor query');
                            callback(null, JsonResponse(200, 'SUCCESS', 'Successfully Fetched Recent Visitor To Given Link', response));
                        }
                    });
                }else{
                    callback(null, JsonResponse(404, 'NOT FOUND', 'No Such Weblink Registered', null));
                } 
            }
        });
    }catch (ex) {
        console.log('exception', ex);
        callback(JsonResponse(500, 'FAILED', JSON.stringify(ex), null));
    }
};

/* Deregester's A Given Link & Does Delete From DB */
const deregisterLink = function (req, callback) {
    try {
        let weblink = req.weblink;
        let findQuery = 'SELECT weblink FROM `WebLinksDB`.`weblink` WHERE weblink = ' + "'" + weblink + "'";
        db.query(findQuery, null, function (error, response) {
            if (error) {
                console.log('Error message', error);
                callback(JsonResponse(500, 'FAILED', JSON.stringify(error), null))
            } else {
                console.log('Inside Find Weblink Query');
                if(response.length > 0){
                        let deregisterLinkQuery = 'UPDATE `WebLinksDB`.`weblink` SET `isActive` = false where weblink = ' + "'" + weblink + "'";
                        db.query(deregisterLinkQuery, null, function (error, response) {
                            if (error) {
                                console.log('Error message', error);
                                callback(JsonResponse(500, 'FAILED', JSON.stringify(error), null))
                            } else {
                                console.log('Inside Deregister Query');
                                callback(null, JsonResponse(200, 'SUCCESS', 'Successfully Deregistered Link', null));
                            }
                        });
                    }else{
                        callback(null, JsonResponse(404, 'NOT FOUND', 'No Such Weblink Registered', null));
                    }
                } 
            })   
    }catch (ex) {
        console.log('exception', ex);
        callback(JsonResponse(500, 'FAILED', JSON.stringify(ex), null));
    }
};

/* Delete's Link Oldan Than 1 year */
const deleteWebLink = function (req, callback) {
    try {
        let getAllDeregisteredQuery = 'SELECT * from `WebLinksDB`.`weblink` WHERE isActive = false';
        db.query(getAllDeregisteredQuery, null, function (error, response) {
            if (error) {
                console.log('Error message', error);
                callback(JsonResponse(500, 'FAILED', JSON.stringify(error), null));
            } else {
                console.log('Inside Get Weblink Query');
                const linkId = response[0].linkId;
                let linkDate = new Date(response[0].createdOn).getTime();
                let dateToCompare = new Date().getTime();
                let yearDifference = (dateToCompare - linkDate) / (365 * 24 * 60 * 60 * 1000);
                yearDifference = Math.floor(yearDifference);
                console.log('yearDifference', yearDifference);
                if (yearDifference < 0) {
                    let deleteQuery = 'DELETE FROM `WebLinksDB`.`weblink` WHERE  linkId = ' + "'" + linkId + "'";
                    db.query(deleteQuery, null, function (error, response) {
                        if (error) {
                            console.log('Error message', error);
                            callback(JsonResponse(500, 'FAILED', JSON.stringify(error), null));
                        } else {
                            console.log('Inside Delete Query');
                            callback(null, JsonResponse(200, 'SUCCESS', null, 'Deleted Successfully'));
                        }
                    });
                } else {
                    callback(null, JsonResponse(200, 'SUCCESS', null, response));
                }
            }
        });
    } catch (ex) {
        console.log(ex);
        callback(JsonResponse(500, 'FAILED', JSON.stringify(error), null));
    }
};

module.exports = {
    getWebLink: getWebLink,
    registerWebLink: registerWebLink,
    updateWebLink: updateWebLink,
    deleteWebLink: deleteWebLink,
    deregisterLink: deregisterLink,
    searchPopularLink: searchPopularLink,
    updateRecentVisitor: updateRecentVisitor,
    getRecentVisitorAllLinks: getRecentVisitorAllLinks,
    getRecentVisitor: getRecentVisitor
}